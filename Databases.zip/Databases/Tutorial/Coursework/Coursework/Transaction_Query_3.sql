SQL> SELECT * FROM CUSTOMER
  2  WHERE 4 <
  3  (SELECT COUNT(*)
  4  FROM INVOICE
  5  WHERE CUSTOMER.CUSTOMER_ID = INVOICE.CUSTOMER_ID);

CUSTOMER_ID               CUSTOMER_NAME             CUSTOMER_PHONE            CUSTOMER_DESCRIPTION      CUSTOMER_CATEGORY                                                                                                                                                                                                                                                                                                                                                                                           
------------------------- ------------------------- ------------------------- ------------------------- -------------------------                                                                                                                                                                                                                                                                                                                                                                                   
C001                      Arteezy                   9988764713                Private Individual        R                                                                                                                                                                                                                                                                                                                                                                                                           
C008                      RapTime                   9564738912                Commercial Business       P                                                                                                                                                                                                                                                                                                                                                                                                           

SQL> SPOOL OFF
