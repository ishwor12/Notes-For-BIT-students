SQL> SELECT C.CUSTOMER_NAME, P.PAINTING_TITLE, I.INVOICE_DATE
  2  FROM CUSTOMER C
  3  JOIN INVOICE I
  4  ON C.CUSTOMER_ID = I.CUSTOMER_ID
  5  JOIN INVOICE_PAINTING IP
  6  ON I.INVOICE_ID = IP.INVOICE_Id
  7  JOIN PAINTING P
  8  ON IP.PAINTING_ID = P.PAINTING_ID
  9  WHERE IP.PAINTING_REQUEST = 'Rent'
 10  AND C.CUSTOMER_ID = 'C001';

CUSTOMER_NAME             PAINTING_TITLE            INVOICE_D                                                                                                                                                                                                                                                                                                                                                                                                                                                       
------------------------- ------------------------- ---------                                                                                                                                                                                                                                                                                                                                                                                                                                                       
Arteezy                   Mice and Me               25-SEP-21                                                                                                                                                                                                                                                                                                                                                                                                                                                       
Arteezy                   White Mised               05-DEC-21                                                                                                                                                                                                                                                                                                                                                                                                                                                       
Arteezy                   White Mised               15-DEC-21                                                                                                                                                                                                                                                                                                                                                                                                                                                       
Arteezy                   White Mised               25-SEP-21                                                                                                                                                                                                                                                                                                                                                                                                                                                       
Arteezy                   Three Trunk               20-AUG-21                                                                                                                                                                                                                                                                                                                                                                                                                                                       

SQL> SPOOL OFF
