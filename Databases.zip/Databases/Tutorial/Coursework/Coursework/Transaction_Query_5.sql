SQL> SELECT A.ARTIST_ID, SUM(IP.ACTUAL_PURCHASE_COST) "TOTAL SOLD COST"
  2  FROM PAINTING P
  3  JOIN ARTIST A
  4  ON P.ARTIST_ID = A.ARTIST_ID
  5  JOIN INVOICE_PAINTING IP
  6  ON P.PAINTING_ID = IP.PAINTING_ID
  7  JOIN INVOICE I
  8  ON IP.INVOICE_ID = I.INVOICE_ID
  9  WHERE IP.PAINTING_REQUEST = 'Purchase'
 10  AND (I.INVOICE_DATE < LAST_DAY(SYSDATE)
 11  AND I.INVOICE_DATE > LAST_DAY(SYSDATE) - 30)
 12  GROUP BY A.ARTIST_ID;

ARTIST_ID                 TOTAL SOLD COST                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
------------------------- ---------------                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
A007                               100500                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
A001                                50000                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
A006                                90000                                                                                                                                                                                                                                                                                                                                                                                                                                                                           

SQL> SPOOL OFF
